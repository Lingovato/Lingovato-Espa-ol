Lingovato-Español V3
Open index.html or publish the folder on an HTTPS static host.
1200 new exercises: 100 conversation prompts and 100 vocabulary items per CEFR-inspired level. 36 original guided dialogues retained. Conversation exercises are open-response, self-assessed, not AI graded. Browser speech recognition and recording depend on device permissions and HTTPS. Progress stored locally.
